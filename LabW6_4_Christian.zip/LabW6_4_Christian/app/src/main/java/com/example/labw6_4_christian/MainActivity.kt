package com.example.labw6_4_christian

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    lateinit var recyclerView:RecyclerView
    lateinit var customAdapter: CustomAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        displayItems()
    }

    private fun displayItems() {
        recyclerView = findViewById(R.id.recycler_main)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = GridLayoutManager(this, 1)

        val myModelList = ArrayList<MyModel>()
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        myModelList.add(MyModel("John", 20))
        customAdapter = CustomAdapter(this, myModelList)
        recyclerView.adapter = customAdapter
    }
}