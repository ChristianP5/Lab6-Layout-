package com.example.labw6_4_christian

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    lateinit var textName: TextView
    lateinit var textAge: TextView

    init {
        // Use itemView to find views within the itemView layout
        textName = itemView.findViewById(R.id.textName)
        textAge = itemView.findViewById(R.id.textAge)
    }
}
