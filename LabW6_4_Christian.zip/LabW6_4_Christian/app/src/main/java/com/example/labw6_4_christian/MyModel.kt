package com.example.labw6_4_christian

class MyModel(name:String, age:Int) {

    var name:String = name
    var age:Int = age



}