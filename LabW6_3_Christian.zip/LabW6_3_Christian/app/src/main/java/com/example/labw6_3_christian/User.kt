package com.example.labw6_3_christian

data class User(val firstName: String, val lastName : String, val age:String)
